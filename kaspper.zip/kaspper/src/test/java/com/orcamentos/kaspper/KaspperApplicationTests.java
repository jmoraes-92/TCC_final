package com.orcamentos.kaspper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaspperApplicationTests {

	@Test
	void contextLoads() {
	}

}
