package com.orcamentos.kaspper.repository;

import com.orcamentos.kaspper.model.Demanda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DemandaRepository extends JpaRepository<Demanda, Long> {
    boolean existsByOrcamentoId(Long orcamentoId);

}
