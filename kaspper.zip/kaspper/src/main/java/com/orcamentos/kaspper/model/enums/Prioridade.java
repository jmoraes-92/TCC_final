package com.orcamentos.kaspper.model.enums;

public enum Prioridade {
    BAIXA, MEDIA, ALTA;
}
