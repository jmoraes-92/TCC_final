CREATE DATABASE IF NOT EXISTS oracamentoskaspper;
USE oracamentoskaspper;
